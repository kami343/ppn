<div class="cityNav">
    <div class="ddsmoothmenu" id="smoothmenu2">
        <ul>
            <li><a href="{{ route('site.what-is-ppn') }}">What Is PPN?</a></li>
            <li><a href="{{ route('site.find-a-league') }}">Find A League</a></li>
            <li><a href="{{ route('site.read-complete-rules') }}">League Rules</a></li>
            <li><a href="{{ route('site.local-court') }}">Pickleball Courts</a></li>
            <li><a href="{{ route('site.faqs') }}">FAQs</a></li>
            <li><a href="{{ route('site.contact-us') }}">Contact Us</a></li>
        </ul>
    </div>
</div>